package com.saki.speeop_alpha_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        var quo = quoteSender()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // Data is displayed in the TextView
        val quote: TextView = findViewById(R.id.quotes) as TextView
        val layla: ImageView = findViewById(R.id.layla_icon) as ImageView

        layla.setOnClickListener {
            quote.text = quo.getquote()
        }

    }
}