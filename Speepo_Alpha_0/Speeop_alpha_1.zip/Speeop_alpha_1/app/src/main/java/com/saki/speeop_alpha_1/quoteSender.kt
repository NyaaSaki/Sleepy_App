package com.saki.speeop_alpha_1

class quoteSender {

    val quo = arrayOf(
        "hi","hello","goodmonfen","goodmorning","im slpee",
        "slep","slepr"," hi <33333","go styef","u bhedi","psl dont satay up late",
        "slope hug ocun +1", "sloepl hug count + 3","sole hug count +2",
        ";-;",":o","o","a","aaa","i m plyifn gensin","o","ypuc an do it i be fiel in you <#33333",
        "ur worth it","ily now go stduy","...","why are otu here","<3","this action was randomly done,for more info pls contact sleepy",
        "where ru",".","ok","o i fgorf",">///////<","i hope ur ok"," o-o ",
        "w ha t","mood","im sple","peep peep" , "chirp chirp","*bird noises*","ad astra abyssosq",
        "hav you tried sperl","bros","o ok","(\u2060ノ\u2060｀\u2060Д\u2060´\u2060)\u2060ノ\u2060彡\u2060┻\u2060━\u2060┻","(\u2060≧\u2060▽\u2060≦\u2060)","ᕙ\u2060(\u2060⇀\u2060‸\u2060↼\u2060‶\u2060)\u2060ᕗ","(\u2060☉\u2060｡\u2060☉\u2060)\u2060!","¯\u2060\\\u2060_\u2060(\u2060ツ\u2060)\u2060_\u2060/\u2060¯","┬\u2060─\u2060─\u2060┬\u2060◡\u2060ﾉ\u2060(\u2060°\u2060 \u2060-\u2060°\u2060ﾉ\u2060)","ಠ\u2060_\u2060ಠ","(\u2060｡\u2060ŏ\u2060﹏\u2060ŏ\u2060)"
    )

    fun getquote() : String{
        return quo.random()
    }
}